# Student Record Management System

## Objective
CLI-based Java application to perform CRUD operations on student records.

## Tools Used
- Java
- VS Code / IntelliJ CE

## Features
- Add new student
- View all students
- Update existing student data
- Delete a student by ID

## Concepts Practiced
- OOP (Encapsulation)
- ArrayList and Collections
- Loops and Conditionals

## How to Run
Compile and run using terminal or any IDE:

```
javac Student.java StudentManagementSystem.java
java StudentManagementSystem
```

## Example Output
```
Student Record Management System
1. Add Student
2. View Students
3. Update Student
4. Delete Student
5. Exit
```

## Submission
Upload this project to your GitHub and submit the link.
